"""Simulated Visual Browser missions.

This module never requests the target URL. It persists a clearly labelled
simulation so the product flow can be exercised before a real, authorized VPS
browser/MCP connection exists.
"""

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from fastapi import APIRouter, HTTPException
from pymongo import ReturnDocument

from lib.db import db
from lib.orchestrator import _post_room, spawn
from models.models import VisualMission, VisualMissionCreate, aware

router = APIRouter()
logger = logging.getLogger(__name__)

STEP_BLUEPRINTS = [
    ("validate", "Validando a ordem"),
    ("session", "Preparando sessão isolada"),
    ("journey", "Mapeando a jornada"),
    ("delivery", "Consolidando a entrega"),
]

ACTION_LABELS = {
    "open": "Abrir página",
    "read": "Ler conteúdo",
    "click": "Clicar",
    "write": "Escrever",
    "copy": "Copiar",
    "paste": "Colar",
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _to_mission(doc: dict) -> VisualMission:
    return VisualMission(
        **{
            **doc,
            "created_at": aware(doc["created_at"]),
            "updated_at": aware(doc["updated_at"]),
        }
    )


def _detail(step_key: str, mission: dict) -> str:
    host = urlparse(mission["url"]).netloc
    objective = mission["objective"]
    details = {
        "validate": f"Alvo reconhecido: {host}. Objetivo recebido sem abrir o endereço.",
        "session": "Sessão simulada preparada. Nenhum login, cookie ou conta real foi utilizado.",
        "journey": f"Roteiro simulado criado para: {objective}",
        "delivery": "Resumo preparado sem captura, leitura ou alteração do site real.",
    }
    return details[step_key]


def _action_target(action_type: str, url: str, objective: str) -> str:
    targets = {
        "open": url,
        "read": f"conteúdo visível relacionado a “{objective[:120]}”",
        "click": "controle necessário para avançar na jornada",
        "write": "campo de entrada relacionado ao objetivo",
        "copy": "resultado principal identificado na simulação",
        "paste": "campo de destino da jornada simulada",
    }
    return targets[action_type]


def _action_output(action_type: str, mission: dict) -> str:
    host = urlparse(mission["url"]).netloc
    objective = mission["objective"]
    outputs = {
        "open": f"Abertura simulada de {host}; nenhuma conexão externa foi realizada.",
        "read": "Leitura simulada concluída sem capturar conteúdo do site real.",
        "click": "Clique simulado registrado; nenhum controle real foi acionado.",
        "write": f"Escrita simulada preparada para o objetivo: {objective[:160]}",
        "copy": "Conteúdo sintético colocado na área de transferência simulada.",
        "paste": "Conteúdo sintético colado no campo de destino simulado.",
    }
    return outputs[action_type]


async def run_visual_mission(mission_id: str) -> None:
    now = _now()
    mission = await db.visual_missions.find_one_and_update(
        {
            "id": mission_id,
            "status": {"$in": ["queued", "running"]},
            "$or": [
                {"lease_until": {"$exists": False}},
                {"lease_until": {"$lte": now}},
            ],
        },
        {
            "$set": {
                "runner_id": uuid.uuid4().hex,
                "lease_until": now + timedelta(minutes=10),
                "updated_at": now,
            },
            "$inc": {"run_attempts": 1},
        },
        return_document=ReturnDocument.AFTER,
    )
    if not mission:
        return

    try:
        mission["status"] = "running"
        mission["updated_at"] = _now()
        await db.visual_missions.update_one(
            {"id": mission_id},
            {"$set": {"status": "running", "updated_at": mission["updated_at"]}},
        )

        steps = mission["steps"]
        for index, step in enumerate(steps):
            if step.get("status") == "completed":
                continue
            await asyncio.sleep(0.7)
            steps[index] = {**step, "status": "completed", "detail": _detail(step["key"], mission)}
            await db.visual_missions.update_one(
                {"id": mission_id},
                {"$set": {"steps": steps, "updated_at": _now()}},
            )

        actions = mission.get("actions", [])
        for index, action in enumerate(actions):
            if action.get("status") == "completed":
                continue
            await asyncio.sleep(0.45)
            actions[index] = {
                **action,
                "status": "completed",
                "output": _action_output(action["type"], mission),
            }
            await db.visual_missions.update_one(
                {"id": mission_id},
                {"$set": {"actions": actions, "updated_at": _now()}},
            )

        host = urlparse(mission["url"]).netloc
        result = (
            f"[MODO SIMULADO] Missão visual planejada para {host}. "
            f"Objetivo: {mission['objective']}\n\n"
            f"{len(actions)} ação(ões) simulada(s): "
            f"{', '.join(ACTION_LABELS[action['type']] for action in actions)}.\n\n"
            "Nenhum site foi aberto e nenhuma conta foi acessada. "
            "Para execução real, conecte e autorize o navegador/MCP da VPS."
        )
        await db.visual_missions.update_one(
            {"id": mission_id},
            {
                "$set": {"status": "completed", "result": result, "steps": steps, "updated_at": _now()},
                "$unset": {"runner_id": "", "lease_until": "", "last_run_error": ""},
            },
        )
        await _post_room(
            "zero",
            "system",
            f"🖥️ Navegador Visual · MODO SIMULADO\n\n{result}",
            message_id=f"visual-delivery-{mission_id}",
        )
    except Exception:
        logger.exception("visual mission %s failed", mission_id)
        await db.visual_missions.update_one(
            {"id": mission_id},
            {
                "$set": {
                    "status": "failed",
                    "result": "[MODO SIMULADO] A simulação foi interrompida antes da entrega.",
                    "last_run_error": "visual_simulation_failed",
                    "updated_at": _now(),
                },
                "$unset": {"runner_id": "", "lease_until": ""},
            },
        )


@router.get("/visual/missions", response_model=list[VisualMission])
async def list_visual_missions():
    docs = await db.visual_missions.find().sort("created_at", -1).to_list(50)
    return [_to_mission(doc) for doc in docs]


@router.get("/visual/missions/{mission_id}", response_model=VisualMission)
async def get_visual_mission(mission_id: str):
    doc = await db.visual_missions.find_one({"id": mission_id})
    if not doc:
        raise HTTPException(status_code=404, detail="visual mission not found")
    return _to_mission(doc)


@router.post("/visual/missions", response_model=VisualMission)
async def create_visual_mission(input: VisualMissionCreate):
    mission = VisualMission(
        url=input.url,
        objective=input.objective,
        steps=[{"key": key, "label": label} for key, label in STEP_BLUEPRINTS],
        actions=[
            {
                "type": action_type,
                "label": ACTION_LABELS[action_type],
                "target": _action_target(action_type, input.url, input.objective),
            }
            for action_type in input.action_types
        ],
    )
    await db.visual_missions.insert_one(mission.model_dump())
    spawn(run_visual_mission(mission.id))
    return mission